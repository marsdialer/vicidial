function ShowWarning() {
	var VWDalert=window.arguments[1];
}