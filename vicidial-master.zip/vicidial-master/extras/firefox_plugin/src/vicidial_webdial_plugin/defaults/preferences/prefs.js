pref("extensions.vicidial_webdial_plugin.boolpref", false);
pref("extensions.vicidial_webdial_plugin.intpref", 0);
pref("extensions.vicidial_webdial_plugin.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.joejohn@vicidial_webdial_plugin.com.description", "chrome://vicidial_webdial_plugin/locale/overlay.properties");
